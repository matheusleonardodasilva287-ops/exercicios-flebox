console.log("Olá, JavaScript!");
